# StrikePot Personal MVP

A mobile-first personal bowling pot manager. It runs in a modern browser and can be installed to the iPhone Home Screen as a web app when hosted over HTTPS. It is a static app: no Firebase, account, backend, or payment processing is required.

## Included features

- Dashboard with active pot count, bowler count, and estimated active prize pools
- Create, edit, complete, and delete pots
- Default 3 games per pot (changeable in Settings)
- Reusable bowler roster and per-pot roster management
- Scratch score entry for 1–10 games, with automatic series totals
- Live series leaderboard
- Configurable payout percentages per pot; percentages must total 100%
- Prize-pool estimate based on roster size × entry fee
- Payment status and method tracking (Venmo, Cash App, Apple Pay, Google Pay, Cash, Other)
- JSON export/import backup
- Local browser persistence and a small service-worker cache for offline app-shell loading

## Run locally on a computer

You can open `index.html` directly for most features, but service-worker installation requires HTTP/HTTPS. For a local server with Python installed:

```bash
cd StrikePot_Personal_MVP
python3 -m http.server 8000
```

Then open `http://localhost:8000` in a browser on that computer.

## Use on your iPhone

The simplest way is to host this folder as a static website on an HTTPS host (for example, GitHub Pages, Netlify, or another static host). Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` together, preserving their names and relative paths. Then:

1. Open the HTTPS site in Safari on the iPhone.
2. Tap Share.
3. Choose **Add to Home Screen**.
4. Launch StrikePot from the Home Screen.
5. Create a pot and export a backup from time to time.

A local computer is not required for daily use once the site is hosted. You will need some way to upload/deploy the files initially. This package is source code, not an App Store/TestFlight install.

## Important data notes

- Data is stored in the browser's local storage on the device. It is not synced to another device.
- Private browsing, clearing Safari website data, changing browser/site origin, or some storage-cleanup actions may remove data. Export backups regularly.
- The service worker caches the app shell only; pot/player data remains in local storage.
- Payment methods are labels only. The app does not initiate payments, store payment credentials, or verify transfers.
- Prize pool is an estimate using all bowlers currently in the pot × entry fee, including bowlers whose payment status is unpaid. The payments tab separately reports marked-paid and outstanding amounts.
- Scoring is scratch-only. No handicap calculations in this milestone.

## Smoke-test checklist

This project was generated as source code. It has **not** been run through a browser automation suite or device build in this environment. After opening it, verify:

1. Create a pot with 3 games and confirm it appears on the dashboard and Pots tab.
2. Add a bowler in Bowlers, then add them to a pot via Manage.
3. Enter scores such as 180, 200, 190 and confirm series total is 570.
4. Open Leaderboard and confirm order changes with scores.
5. Set payout percentages to 60/25/15 and save; verify total is 100%.
6. Mark a bowler paid, change their payment method, and check totals.
7. Export a JSON backup, reset data only if safe, and import the backup.
8. On iPhone, install from an HTTPS host and verify Home Screen launch and persistence after closing/reopening.

## Remaining work

- Automated unit/UI tests and real iPhone Safari verification
- Optional PIN/Face ID gate and safer deletion undo
- Cloud backup/sync and multi-device access (later phase)
- Native iOS/Android wrappers if App Store distribution is desired
- Real payment provider links/integrations, if desired; this requires separate provider-specific decisions and should not be treated as payment processing in this MVP
- Additional bowling rules such as handicap scoring (intentionally excluded from this scratch-only milestone)
